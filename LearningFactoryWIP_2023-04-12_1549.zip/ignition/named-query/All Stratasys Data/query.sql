select * from lf.strata1 order by timestamp desc
