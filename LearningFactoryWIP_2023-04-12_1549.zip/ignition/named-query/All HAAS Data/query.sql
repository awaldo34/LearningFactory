SELECT * FROM lf.haas ORDER BY timestamp DESC
